<template>
    <div>
      <h1>角色管理</h1>
      <p>Hello, World!</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Role',
    // 这里可以添加更多的组件选项，如数据、方法、计算属性等
  };
  </script>
  
  <style scoped>
  /* 您可以在这里添加样式 */
  </style>
  